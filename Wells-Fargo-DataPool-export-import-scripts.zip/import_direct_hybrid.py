#
# Example script for uploading a json file directly into event collection on-prem
# 
# Install:
#
# pip install pyjwt
# pip install requests
#
# Use python 3.9
#
# Please adopt the inputs before usage

import requests
import jwt
import time

## INPUT - GENERAL
host = 'localhost' # replace from application-local-yml
port = '8682' # replace from application-local-yml
jwt_secret = "1KAByzNQf0y3YKpbUclrEx5mT06xlRble3sKIVCXN0qj" # replace from application-local-yml
input_file_name = "Test_Export.json" # replace with pool json name

## INPUT - TEAM & USER DETAILS
team_id = "26bce62d-766f-48bc-b9ce-45c02150ebf5" # replace from application-local-yml
user_id = "9d328b18-5781-4ba1-a823-04522194ac9f" # relace from API-call result from Team-Settings (see attached picture)
team_domain = "teamName" # replace from application-local-yml

integration_url = 'http://' + host + ':' + port + '/integration-hybrid'
import_api = integration_url + "/api/pool-import"
input_file = open(input_file_name, "r")
expiry = int(time.time()) + 10*1000

## BUILDING JWT
message = {
  "sub": user_id,
  "teams": [
    {
      "id": team_id,
      "domain": team_domain,
      "role": 3, # Cloud User
      "featureKeys": [
         "hybrid", # Needed for API Access
        "integration.database" # Needed for permissions for connector
      ]
    }
  ],
  "scopes": [
    "api-key"
  ],
  "language": "en",
  "exp": expiry
}

encoded_jwt = str(jwt.encode(message, jwt_secret, algorithm="HS512"))

headers = {
   'authorization': 'Bearer ' + encoded_jwt,
   'x-celonis-team-id': team_id,
   'X-Celonis-Team-Domain': team_domain 
}

response = requests.post(import_api, data = input_file, headers=headers, allow_redirects=False)

if response.status_code == 200:
   print("Successfully imported pool with id '" + str(response.json()["dataPool"]["id"]) + "' and name '" + str(response.json()["dataPool"]["name"]) + "'")
else :
   print("Error while importing: " + response.text + ", code: " + str(response.status_code))
