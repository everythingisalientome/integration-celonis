#
# Example script for exporting a data pool
#
import requests
import json

pool_id = 'poolId' # replace pool id
team = 'teamName' # replace team name
realm = 'cluster' # replace custer e.g. eu-1
url = ' https://' + team + '.' + realm + '.celonis.cloud/integration-hybrid//api/pools/' + pool_id + '/export'

response = requests.get(url, headers={ 'authorization': 'Bearer NzEwY2QxZGMtNDExYy00YmFlLTk1OGYtYzlhN2I4OGVjNGY5OnpKT0lkZ29xbEQva1llazRMclNldzRoYTNtZnFOdnZ1cUliRzdldGRZandO' }) # replace API Key from cloud - please keep the part 'Bearer '
parsed = response.json()
print(json.dumps(parsed, indent=4, sort_keys=False))
